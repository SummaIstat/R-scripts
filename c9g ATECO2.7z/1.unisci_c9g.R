#---------------------------------------------------
# Input files:
# RDFbalanced_train.txt = predicted values (0/1) in the sample 
# prob_RDF_train.txt = predicted probabilities in the sample 
# RDFbalanced.txt = predicted values (0/1) in the population
# prob_RDF = predicted probabilities in the population
# surveyICT2017.txt = survey data
# universo_riporto.txt = population register (ASIA)
#---------------------------------------------------
# Output files:
# ict2017_c9f.txt = predicted values (0/1) in sample and population
# train_probs.txt = predicted probabilities in sample and population
#---------------------------------------------------



#library(data.table)
#
# Train data
# These are the predictions made on sampling units with scraped websites
train <- read.delim("g_train.txt",header=TRUE,sep=" ")
train <- train[,c(1,3)]
colnames(train) <- c("codice_unita","pred")
sum(train$pred)
write.table(train,"train_preds.txt",sep="\t",row.names=F,col.names=T,quote=F)

# These are the predictions made on sampling units with scraped websites
test <- read.delim("g_test.txt",sep=" ")
colnames(test) <- c("codice_unita","pred")
sum(test$pred_prob)
write.table(test,"test_preds.txt",sep="\t",row.names=F,col.names=T,quote=F)

# obs_and_pred <- NULL
# obs_and_pred$codice_unita <- train$Azienda
# obs_and_pred$WEBSM <- train$type
# obs_and_pred$WEB <- 1
# obs_and_pred$mode <- "obs_and_pred"
# obs_and_pred <- as.data.frame(obs_and_pred)
# survey data
survey <- read.delim("surveyICT2017.txt")
table(survey$WEB,useNA="ifany")
survey <- survey[survey$WEB ==1,]
obs <- NULL
obs$codice_unita <- survey$codice_unita
obs$WEB <- ifelse(is.na(survey$WEB),0,survey$WEB)
obs$WEBSM <- ifelse(is.na(survey$WEBSM),0,survey$WEBSM)
#obs$coef_cal <- survey$coef_cal
obs <- as.data.frame(obs)
#obs <- obs[!is.na(obs$WEBSM),]
obs$mode <- ifelse(obs$codice_unita %in% train$codice_unita,"obs_and_pred","obs")
table(obs$mode,obs$WEB,useNA="ifany")
table(obs$mode,obs$WEBSM,useNA="ifany")
# predicted data
pred <- read.delim("test_preds.txt")

# obs <- read.delim("matrix_train.txt",sep=" ")
pred$WEB <- 1
pred$mode <- "pred"
colnames(pred) <- c("codice_unita","WEBSM","WEB","mode")

ict <- rbind(obs,pred)
table(ict$mode,ict$WEBSM)
rowSums(table(ict$mode,ict$WEBSM))
table(ict$mode,ict$WEBSM)/rowSums(table(ict$mode,ict$WEBSM))

# Read population
asia <- read.csv("pop.csv")

ict <- merge(ict, asia, by=c("codice_unita"))
table(ict$mode,ict$WEB)
write.table(ict,"ict2017_c9g.txt",sep="\t",row.names=F,col.names=T,quote=F)

