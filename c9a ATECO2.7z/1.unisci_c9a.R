#---------------------------------------------------
# Input files:
# RDFbalanced_train.txt = predicted values (0/1) in the sample 
# prob_RDF_train.txt = predicted probabilities in the sample 
# RDFbalanced.txt = predicted values (0/1) in the population
# prob_RDF = predicted probabilities in the population
# surveyICT2017.txt = survey data
# universo_riporto.txt = population register (ASIA)
#---------------------------------------------------
# Output files:
# ict2017_c9f.txt = predicted values (0/1) in sample and population
# train_probs.txt = predicted probabilities in sample and population
#---------------------------------------------------



#library(data.table)
#
# Train data
# These are the predictions made on sampling units with scraped websites
train_pred <- read.delim("RDFbalanced_train.txt",header=FALSE,sep=" ")
train_prob <- read.delim("prob_RDF_train.txt",sep=" ",header=FALSE)
train <- cbind(train_pred,train_prob)
train <- train[,c(1,2,4)]
colnames(train) <- c("codice_unita","pred","pred_prob")
sum(train$pred_prob)
write.table(train,"train_probs.txt",sep="\t",row.names=F,col.names=T,quote=F)

# These are the predictions made on sampling units with scraped websites
test_pred <- read.delim("RDFbalanced_test.txt",header=FALSE,sep=" ")
test_prob <- read.delim("prob_RDF_test.txt",sep=" ",header=FALSE)
test <- cbind(test_pred,test_prob)
test <- test[,c(1,2,4)]
colnames(test) <- c("codice_unita","pred","pred_prob")
sum(test$pred_prob)
write.table(test,"test_probs.txt",sep="\t",row.names=F,col.names=T,quote=F)

# obs_and_pred <- NULL
# obs_and_pred$codice_unita <- train$Azienda
# obs_and_pred$WEBORD <- train$type
# obs_and_pred$WEB <- 1
# obs_and_pred$mode <- "obs_and_pred"
# obs_and_pred <- as.data.frame(obs_and_pred)
# survey data
survey <- read.delim("surveyICT2017.txt")
table(survey$WEB,useNA="ifany")
survey <- survey[survey$WEB ==1,]
obs <- NULL
obs$codice_unita <- survey$codice_unita
obs$WEB <- ifelse(is.na(survey$WEB),0,survey$WEB)
obs$WEBORD <- ifelse(is.na(survey$WEBORD),0,survey$WEBORD)
#obs$coef_cal <- survey$coef_cal
obs <- as.data.frame(obs)
#obs <- obs[!is.na(obs$WEBORD),]
obs$mode <- ifelse(obs$codice_unita %in% train$codice_unita,"obs_and_pred","obs")
table(obs$mode,obs$WEB,useNA="ifany")
table(obs$mode,obs$WEBORD,useNA="ifany")
# predicted data
pred <- read.delim("RDFbalanced_test.txt",sep= " ",header=FALSE)
pred <- pred[,c(1:2)]
# obs <- read.delim("matrix_train.txt",sep=" ")
pred$WEB <- 1
pred$mode <- "pred"
colnames(pred) <- c("codice_unita","WEBORD","WEB","mode")

ict <- rbind(obs,pred)
table(ict$mode,ict$WEBORD)
rowSums(table(ict$mode,ict$WEBORD))
table(ict$mode,ict$WEBORD)/rowSums(table(ict$mode,ict$WEBORD))

# Read population
asia <- read.csv("pop.csv")
asia$ATECO2 <- as.factor(substr(asia$ATECO,1,2))
length(levels(asia$ATECO2))
write.table(asia,"pop.csv",sep=",",row.names=F,col.names=T,quote=F)

ict <- merge(ict, asia, by=c("codice_unita"))
table(ict$mode,ict$WEB)
write.table(ict,"ict2017_c9a.txt",sep="\t",row.names=F,col.names=T,quote=F)

