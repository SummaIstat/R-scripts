#------------------------------------------------------------------------------------
# ICT estimation of web ordering
# Design based
# Version using coef.cal
#------------------------------------------------------------------------------------
# Read population
#library(data.table)
asia <- read.csv("pop.csv")
asia$naceICT <- as.factor(asia$naceICT)
asia$naceist <- as.factor(asia$naceist)
asia$mac4 <- as.factor(asia$mac4)
asia$clad4 <- as.factor(asia$clad4)
asia$reg21 <- as.factor(asia$reg21)
asia$TN <- as.factor(asia$TN)

table(asia$naceICT)
table(asia$naceist)
table(asia$mac4)
table(asia$clad4)
table(asia$reg21)
#------------------------------------------------------------------------------------
# Read survey data
survey <- read.delim("surveyICT2017.txt")
colnames(survey)[1] <- "codice"
survey <- merge(survey,asia,by=c("codice"))
survey$naceICT <- as.factor(survey$naceICT)
survey$naceist <- as.factor(survey$naceist)
survey$mac4 <- as.factor(survey$mac4)
survey$clad4 <- as.factor(survey$clad4)
survey$reg21 <- as.factor(survey$reg21)
survey$TN <- as.factor(survey$TN)
# survey$cens <- ifelse(
#   (survey$clad4 == "cl4" | survey$naceist == "ist21" | 
#      (survey$naceist == "ist14" & survey$clad4 == "cl3")
#    | survey$naceist == "ist28"), 1, 0 )
# table(survey$cens)
#survey$stratum <- as.factor(paste("cens","naceist","naceICT","mac4","clad4","reg21",sep=""))
survey$WEB <- ifelse(is.na(survey$WEB),0,survey$WEB)
table(survey$WEB,useNA="ifany")

survey$WEBORD <- ifelse(is.na(survey$WEBORD),0,survey$WEBORD)
table(survey$WEBORD,useNA="ifany")
#------------------------------------------------------------------------------------
# Estimates of population with websites

website_tot <- round(sum(survey$WEB * survey$coef.cal))
website_tot

website_naceist <- round(tapply(survey$WEB * survey$coef.cal,survey$naceist,sum))
website_naceist

website_naceICT <- round(tapply(survey$WEB * survey$coef.cal,survey$naceICT,sum))
website_naceICT

website_clad4 <- round(tapply(survey$WEB * survey$coef.cal,survey$clad4,sum))
website_clad4

website_reg21 <- round(tapply(survey$WEB * survey$coef.cal,survey$reg21,sum))
website_reg21

website_dom3 <- round(tapply(survey$WEB * survey$coef.cal,survey$dom3,sum))
website_dom3

websites <- c(website_tot,
              website_naceist,
              website_naceICT,
              website_clad4,
              website_dom3,
              website_reg21)



#------------------------------------------------------------------------------------
# Estimates of web-ordering

WEBORD_tot <- round(sum(survey$WEBORD * survey$coef.cal))
WEBORD_tot

WEBORD_naceist <- round(tapply(survey$WEBORD * survey$coef.cal,survey$naceist,sum))
WEBORD_naceist

WEBORD_naceICT <- round(tapply(survey$WEBORD * survey$coef.cal,survey$naceICT,sum))
WEBORD_naceICT

WEBORD_clad4 <- round(tapply(survey$WEBORD * survey$coef.cal,survey$clad4,sum))
WEBORD_clad4

WEBORD_reg21 <- round(tapply(survey$WEBORD * survey$coef.cal,survey$reg21,sum))
WEBORD_reg21

WEBORD_dom3 <- round(tapply(survey$WEBORD * survey$coef.cal,survey$dom3,sum))
WEBORD_dom3



out <- NULL
out$dom <- c("Total",rep("naceist",27),
             rep("naceICT",2),
             rep("clad4",4),
             rep("dom3",16),
             rep("reg21",21))
out$estimate <- c("Total",
                  levels(survey$naceist),
                  levels(survey$naceICT),
                  levels(survey$clad4),
                  levels(survey$dom3),
                  levels(survey$reg21))
out$sample <- c(nrow(survey),
                as.numeric(table(survey$naceist)),
                as.numeric(table(survey$naceICT)),
                as.numeric(table(survey$clad4)),
                as.numeric(table(survey$dom3)),
                as.numeric(table(survey$reg21)))
out$population <- c(nrow(asia),
                    as.numeric(table(asia$naceist)),
                    as.numeric(table(asia$naceICT)),
                    as.numeric(table(asia$clad4)),
                    as.numeric(table(asia$dom3)),
                    as.numeric(table(asia$reg21)))
out$websites <- websites
out$webordering <- c(round(WEBORD_tot),
                     round(WEBORD_naceist),
                     round(WEBORD_naceICT),
                     round(WEBORD_clad4),
                     round(WEBORD_dom3),
                     round(WEBORD_reg21))
out <- as.data.frame((out))
out$websites_100 <- round(out$websites * 100 / out$population,2)
out$webordering_100 <- round(out$webordering * 100 / out$population,2)

write.table(out,"ICT_estimates_design_coef.cal.csv",sep=";",row.names=F,col.names=TRUE,quote=FALSE)

