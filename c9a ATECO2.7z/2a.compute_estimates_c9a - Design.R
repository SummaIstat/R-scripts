#------------------------------------------------------------------------------------
# ICT estimation of web ordering
# Design based
#------------------------------------------------------------------------------------
# Read population
#library(data.table)
asia <- read.csv("pop.csv")
asia$naceICT <- as.factor(asia$naceICT)
asia$naceist <- as.factor(asia$naceist)
asia$mac4 <- as.factor(asia$mac4)
asia$clad4 <- as.factor(asia$clad4)
asia$reg21 <- as.factor(asia$reg21)
asia$ATECO2 <- as.factor(asia$ATECO2)
asia$TN <- as.factor(asia$TN)

table(asia$naceICT)
table(asia$naceist)
table(asia$mac4)
table(asia$clad4)
table(asia$reg21)
table(asia$ATECO2)
#------------------------------------------------------------------------------------
# Read survey data
survey <- read.delim("surveyICT2017.txt")
survey$ATECO2 <- as.factor(substr(survey$ATECO,1,2))
table(survey$ATECO2)
length(levels(survey$ATECO2))
write.table(survey,"surveyICT2017.txt",sep="\t",row.names=F,col.names=T,quote=F)
# colnames(survey)[1] <- "codice"
# survey <- merge(survey,asia,by=c("codice_unita"))
# survey$naceICT <- as.factor(survey$naceICT)
# survey$naceist <- as.factor(survey$naceist)
# survey$mac4 <- as.factor(survey$mac4)
# survey$clad4 <- as.factor(survey$clad4)
# survey$reg21 <- as.factor(survey$reg21)
# survey$TN <- as.factor(survey$TN)
# survey$cens <- ifelse(
#   (survey$clad4 == "cl4" | survey$naceist == "ist21" | 
#      (survey$naceist == "ist14" & survey$clad4 == "cl3")
#    | survey$naceist == "ist28"), 1, 0 )
# table(survey$cens)
# survey$stratum <- as.factor(paste("cens","naceist","naceICT","mac4","clad4","reg21",sep=""))
survey$WEB <- ifelse(is.na(survey$WEB),0,survey$WEB)
table(survey$WEB,useNA="ifany")

survey$WEBORD <- ifelse(is.na(survey$WEBORD),0,survey$WEBORD)
table(survey$WEBORD,useNA="ifany")
#------------------------------------------------------------------------------------
# Estimates of population with websites

library(ReGenesees)

camp <- e.svydesign(data= survey, ids= ~ codice_unita, strata= ~ strato, 
                    weights= ~ coef, fpc= NULL, self.rep.str= NULL, check.data= TRUE)


options(RG.lonely.psu = "average")
tot_cov = pop.template(data = survey, 
                       calmodel = ~(imprese + ADDETTI):((ATECO2 + naceICT):TN + clad4 + reg21) - 1, 
                       partition = ~mac4)
tot_cov = fill.template(universe = asia, template = tot_cov)

# sum(tot_cov)

bounds.hint(camp, tot_cov)
#pop.desc(tot_cov)
camp_cal = e.calibrate(design = camp, df.population = tot_cov,
  # calmodel = ~(imprese + ADDETTI):((ATECO2.in.mac4 + naceICT):TN + clad4 + reg21) - 1, 
  #               partition = ~mac4,
  calmodel = ~(imprese + ADDETTI):((ATECO2 + naceICT):TN + clad4 + reg21) - 1, 
  partition = ~mac4,
  calfun = "linear", bounds = c(-1E12, 1E12), aggregate.stage = NULL, sigma2 = ~ADDETTI,
  maxit = 50, epsilon = 1e-07, force = TRUE)


summary(weights(camp_cal))
g.range(camp_cal)
check.cal(camp_cal)

website_tot <- svystatTM(camp_cal, y= ~ WEB ,  estimator= "Mean", 
                         conf.int= TRUE, conf.lev= 0.95, deff= FALSE, na.rm= FALSE)
Zapsmall(website_tot)

website_ATECO2 <- svystatTM(camp_cal, y= ~ WEB ,  estimator= "Mean", 
                             by =~ATECO2 - 1,
                             conf.int= TRUE, conf.lev= 0.95, deff= FALSE, na.rm= FALSE)

website_naceist <- svystatTM(camp_cal, y= ~ WEB ,  estimator= "Mean", 
                     by =~naceist - 1,
                     conf.int= TRUE, conf.lev= 0.95, deff= FALSE, na.rm= FALSE)
Zapsmall(website_naceist)
website_naceICT <- svystatTM(camp_cal, y= ~ WEB ,  estimator= "Mean", 
                             by =~naceICT - 1,
                             conf.int= TRUE, conf.lev= 0.95, deff= FALSE, na.rm= FALSE)
Zapsmall(website_naceICT)
website_clad4 <- svystatTM(camp_cal, y= ~ WEB ,  estimator= "Mean", 
                             by =~clad4 - 1,
                             conf.int= TRUE, conf.lev= 0.95, deff= FALSE, na.rm= FALSE)
Zapsmall(website_clad4)
website_reg21 <- svystatTM(camp_cal, y= ~ WEB ,  estimator= "Mean", 
                               by =~reg21 - 1,
                               conf.int= TRUE, conf.lev= 0.95, deff= FALSE, na.rm= FALSE)
Zapsmall(website_reg21)

website_dom3 <- svystatTM(camp_cal, y= ~ WEB ,  estimator= "Mean", 
                           by =~dom3 - 1,
                           conf.int= TRUE, conf.lev= 0.95, deff= FALSE, na.rm= FALSE)
Zapsmall(website_dom3)

website <- svystatTM(camp_cal, y= ~ WEB ,  estimator= "Mean", 
                     #                     vartype= c("cv"), 
                     conf.int= TRUE, conf.lev= 0.95, deff= FALSE, na.rm= FALSE)
Zapsmall(website)

websites <- c(website_naceist$Mean.WEB,
              website_naceICT$Mean.WEB[2],
              website_clad4$Mean.WEB[2:4],
              website_reg21$Mean.WEB[2:21],
              website_ATECO2$Mean.WEB[2:62])



#------------------------------------------------------------------------------------
# Estimates of web-ordering

webordTotal <- svystatTM(camp_cal, y= ~ WEBORD,  estimator= "Mean", 
                            conf.int= TRUE, conf.lev= 0.95, deff= FALSE, na.rm= FALSE)

              
Zapsmall(webordTotal)

webord_ATECO2 <- svystatTM(camp_cal, y= ~ WEBORD ,  estimator= "Mean", 
                             by =~ATECO2 - 1,
                             conf.int= TRUE, conf.lev= 0.95, deff= FALSE, na.rm= FALSE)

Zapsmall(webord_ATECO2)

webord_naceist <- svystatTM(camp_cal, y= ~ WEBORD,  estimator= "Mean", 
                            by =~naceist - 1,
                            conf.int= TRUE, conf.lev= 0.95, deff= FALSE, na.rm= FALSE)

Zapsmall(webord_naceist)

webord_naceICT <- svystatTM(camp_cal, y= ~ WEBORD,  estimator= "Mean", 
                            by =~naceICT - 1,
                            conf.int= TRUE, conf.lev= 0.95, deff= FALSE, na.rm= FALSE)

Zapsmall(webord_naceICT)

webord_clad4 <- svystatTM(camp_cal, y= ~ WEBORD,  estimator= "Mean", 
                            by =~clad4 - 1,
                            conf.int= TRUE, conf.lev= 0.95, deff= FALSE, na.rm= FALSE)

Zapsmall(webord_clad4)

webord_dom3 <- svystatTM(camp_cal, y= ~ WEBORD,  estimator= "Mean", 
                            by =~dom3 - 1,
                            conf.int= TRUE, conf.lev= 0.95, deff= FALSE, na.rm= FALSE)

Zapsmall(webord_dom3)

webord_reg21 <- svystatTM(camp_cal, y= ~ WEBORD,  estimator= "Mean", 
                            by =~reg21 - 1,
                            conf.int= TRUE, conf.lev= 0.95, deff= FALSE, na.rm= FALSE)

Zapsmall(webord_reg21)


out <- NULL
out$dom <- c("Total",rep("naceist",27),
             rep("naceICT",2),
             rep("clad4",4),
             rep("dom3",16),
             rep("reg21",21),
             rep("ATECO2",62))
out$estimate <- c("Total",
                  levels(survey$naceist),
                  levels(survey$naceICT),
                  levels(survey$clad4),
                  levels(survey$dom3),
                  levels(survey$reg21),
                  levels(survey$ATECO2))
out$sample <- c(nrow(survey),
                as.numeric(table(survey$naceist)),
                as.numeric(table(survey$naceICT)),
                as.numeric(table(survey$clad4)),
                as.numeric(table(survey$dom3)),
                as.numeric(table(survey$reg21)),
                as.numeric(table(survey$ATECO2)))
out$population <- c(nrow(asia),
                    as.numeric(table(asia$naceist)),
                    as.numeric(table(asia$naceICT)),
                    as.numeric(table(asia$clad4)),
                    as.numeric(table(asia$dom3)),
                    as.numeric(table(asia$reg21)),
                    as.numeric(table(asia$ATECO2)))
out$websites <- c(round(website$Mean*nrow(asia)),
                  round(website_naceist$Mean*as.numeric(table(asia$naceist))),
                  round(website_naceICT$Mean*as.numeric(table(asia$naceICT))),
                  round(website_clad4$Mean*as.numeric(table(asia$clad4))),
                  round(website_dom3$Mean*as.numeric(table(asia$dom3))),
                  round(website_reg21$Mean*as.numeric(table(asia$reg21))),
                  round(website_ATECO2$Mean*as.numeric(table(asia$ATECO2))))
out$webordMean <- c(round(webordTotal$Mean*100,2),
                     round(webord_naceist$Mean*100,2),
                     round(webord_naceICT$Mean*100,2),
                     round(webord_clad4$Mean*100,2),
                     round(webord_dom3$Mean*100,2),
                     round(webord_reg21$Mean*100,2),
                     round(webord_ATECO2$Mean*100,2))
out$webordLower <- c(round(webordTotal$`CI.l(95%)`*100,2),
                    round(webord_naceist$`CI.l(95%)`*100,2),
                    round(webord_naceICT$`CI.l(95%)`*100,2),
                    round(webord_clad4$`CI.l(95%)`*100,2),
                    round(webord_dom3$`CI.l(95%)`*100,2),
                    round(webord_reg21$`CI.l(95%)`*100,2),
                    round(webord_ATECO2$`CI.l(95%)`*100,2))
out$webordUpper <- c(round(webordTotal$`CI.u(95%)`*100,2),
                    round(webord_naceist$`CI.u(95%)`*100,2),
                    round(webord_naceICT$`CI.u(95%)`*100,2),
                    round(webord_clad4$`CI.u(95%)`*100,2),
                    round(webord_dom3$`CI.u(95%)`*100,2),
                    round(webord_reg21$`CI.u(95%)`*100,2),
                    round(webord_ATECO2$`CI.u(95%)`*100,2))
out <- as.data.frame((out))


write.table(out,"ICT_estimates_design.csv",sep=";",row.names=F,col.names=TRUE,quote=FALSE)

