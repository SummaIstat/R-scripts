#------------------------------------------------------------------------------------
# ICT estimation of web ordering
# COMBINED METHOD with model assisted variant
# y = sum(predicted) + 
# weighted_sum_on_U1(diff(observed_and_predicted)) +
# weighted_sum_on_U2(only_observed)
#------------------------------------------------------------------------------------
# Read population
#library(data.table)
asia <- read.csv("pop.csv")
#asia <- read.delim("universo_riporto.txt")
asia$naceICT <- as.factor(asia$naceICT)
asia$naceist <- as.factor(asia$naceist)
asia$mac4 <- as.factor(asia$mac4)
asia$clad4 <- as.factor(asia$clad4)
asia$reg21 <- as.factor(asia$reg21)
asia$TN <- as.factor(asia$TN)
asia$ATECO2 <- as.factor(asia$ATECO2)

# table(asia$naceICT)
# table(asia$naceist)
# table(asia$mac4)
# table(asia$clad4)
# table(asia$reg21)
#------------------------------------------------------------------------------------
# Read survey data
survey <- read.delim("surveyICT2017.txt")
# survey <- survey[,c(1:8)]
# survey <- merge(survey,asia,by=c("codice_unita"))
# survey$naceICT <- as.factor(survey$naceICT)
# survey$naceist <- as.factor(survey$naceist)
# survey$mac4 <- as.factor(survey$mac4)
# survey$clad4 <- as.factor(survey$clad4)
# survey$reg21 <- as.factor(survey$reg21)
# survey$TN <- as.factor(survey$TN)
# survey$cens <- ifelse(
#   (survey$clad4 == "cl4" | survey$naceist == "ist21" |
#      (survey$naceist == "ist14" & survey$clad4 == "cl3")
#    | survey$naceist == "ist28"), 1, 0 )
# 
# survey$stratum <- as.factor(paste("cens","naceist","naceICT","mac4","clad4","reg21",sep=""))
# survey$WEB <- ifelse(is.na(survey$WEB),0,survey$WEB)
# table(survey$WEB,useNA="ifany")
survey$WEB <- ifelse(is.na(survey$WEB),0,survey$WEB)
table(survey$WEB,useNA="ifany")

survey$WEBORD <- ifelse(is.na(survey$WEBORD),0,survey$WEBORD)
table(survey$WEBORD,useNA="ifany")
#------------------------------------------------------------------------------------
# Estimates of population with websites

website_tot <- sum(survey$WEB * survey$coef.cal)


website_naceist <- tapply(survey$WEB * survey$coef.cal,survey$naceist,sum)/tapply(survey$coef.cal,survey$naceist,sum)
website_naceist

website_naceICT <- tapply(survey$WEB * survey$coef.cal,survey$naceICT,sum)/tapply(survey$coef.cal,survey$naceICT,sum)
website_naceICT

website_clad4 <- tapply(survey$WEB * survey$coef.cal,survey$clad4,sum)/tapply(survey$coef.cal,survey$clad4,sum)
website_clad4

website_reg21 <- tapply(survey$WEB * survey$coef.cal,survey$reg21,sum)/tapply(survey$coef.cal,survey$reg21,sum)
website_reg21

website_dom3 <- tapply(survey$WEB * survey$coef.cal,survey$dom3,sum)/tapply(survey$coef.cal,survey$dom3,sum)
website_dom3

website_ATECO2 <- tapply(survey$WEB * survey$coef.cal,survey$ATECO2,sum)/tapply(survey$coef.cal,survey$ATECO2,sum)
website_ATECO2

websites <- c(website_naceist,
              website_naceICT[2],
              website_clad4[2:4],
              website_dom3[2:16],
              website_reg21[2:21],
              website_ATECO2[2:62])

#------------------------------------------------------------------------------------
# Read ICT data (obs+pred)
ict <- read.table("ict2017_c9a.txt",sep="\t",header=TRUE)
ict$wgt <- nrow(asia)/nrow(ict)
ict$ATECO2 <- as.factor(ict$ATECO2)
ict$stratum <- as.factor(paste(ict$naceist,ict$naceICT,ict$clad4,ict$reg21,sep=""))
table(ict$mode,ict$WEBORD)
rowSums(table(ict$mode,ict$WEBORD))
table(ict$mode,ict$WEBORD)/rowSums(table(ict$mode,ict$WEBORD))

#probs <- read.delim("A_prob_RDF.txt",sep=" ")

#------------------------------------------------------------------------------------
# U1

#------------------------------------------
# Attribution of predicted scores to WEBORD
tapply(ict$WEBORD,ict$mode,sum)
pred <- read.delim("test_probs.txt")
pred <- pred[order(pred$codice_unita),]
ict <- ict[order(ict$codice_unita),]
ict$WEBORD[ict$mode=="pred"] <- pred$pred_prob
tapply(ict$WEBORD,ict$mode,sum)
pred <- merge(pred,asia,by=c("codice_unita"))
# 
# pred <- read.delim("train_probs.txt")
# pred <- pred[order(pred$codice_unita),]
# pred <- pred[pred$codice_unita %in% ict$codice_unita[ict$mode == "obs_and_pred"],]
# ict <- ict[order(ict$codice_unita),]
# ict$WEBORD[ict$mode=="obs_and_pred"] <- pred$pred_prob
# tapply(ict$WEBORD,ict$mode,sum)

preds <- read.delim("train_probs.txt")

obs_and_pred <- merge(ict[ict$mode=="obs_and_pred",],preds,by=c("codice_unita"))
obs_and_pred$ATECO2 <- as.factor(obs_and_pred$ATECO2)
obs_and_pred$diff <- obs_and_pred$WEBORD - obs_and_pred$pred_prob


library(ReGenesees) 
camp_U1 <- e.svydesign(obs_and_pred, ids= ~ codice_unita, strata= ~ stratum, 
                       weights= ~ wgt, fpc= NULL, self.rep.str= NULL, check.data= TRUE)

reached_websites <- nrow(ict[ict$mode == "pred" | ict$mode == "obs_and_pred",]) / nrow(asia)
options(RG.lonely.psu = "average")
tot_U1= pop.template(data = obs_and_pred, 
                       calmodel = ~ATECO2 + naceICT + clad4 + reg21 - 1) 
tot_U1 = fill.template(universe = asia, template = tot_U1)
tot_U1_web = tot_U1
tot_U1_web[,] = tot_U1 * reached_websites
sum(tot_U1_web[1:62])

bounds.hint(camp_U1, tot_U1_web)
#pop.desc(tot_cov)
camp_cal_U1 = e.calibrate(design = camp_U1, df.population = tot_U1_web,
                       calmodel = ~ATECO2 + naceICT + clad4 + reg21 - 1,
                       calfun = "linear", bounds = c(0.1, 37.491), aggregate.stage = NULL, 
                       # sigma2 = ~ADDETTI,
                       maxit = 50, epsilon = 1e-07, force = TRUE)


summary(weights(camp_cal_U1))
g.range(camp_cal_U1)
check.cal(camp_cal_U1)


#------------------------------------------------------------------------------------
# U2
obs <- ict[ict$mode=="obs",]
camp_U2 <- e.svydesign(data= obs, ids= ~ codice_unita, strata= ~ stratum, 
                       weights= ~ wgt, fpc= NULL, self.rep.str= NULL, check.data= TRUE)

# not_reached_websites <- (nrow(asia)*website$Mean - 
#                         nrow(ict[ict$mode=="pred" | ict$mode == "obs_and_pred",])) / nrow(asia)
not_reached_websites <- (website_tot  - 
                           nrow(ict[ict$mode=="pred" | ict$mode == "obs_and_pred",])) / nrow(asia)

options(RG.lonely.psu = "average")
tot_U2 = pop.template(data = ict, 
                       calmodel = ~naceist + naceICT + clad4 + reg21 - 1) 
tot_U2 = fill.template(universe = asia, template = tot_U2)
tot_U2_web = tot_U2
tot_U2_web[,] = tot_U2 * not_reached_websites
sum(tot_U2_web[1:27])

bounds.hint(camp_U2, tot_U2_web)
#pop.desc(tot_cov)
camp_cal_U2 = e.calibrate(design = camp_U2, df.population = tot_U2_web,
                       calmodel = ~naceist + naceICT + clad4 + reg21 - 1,
                       calfun = "linear", bounds = c(0.1, 35), aggregate.stage = NULL, 
                       # sigma2 = ~ADDETTI,
                       maxit = 50, epsilon = 1e-07, force = TRUE)


summary(weights(camp_cal_U2))
g.range(camp_cal_U2)
check.cal(camp_cal_U2)
sum(camp_cal_U2$variables$wgt.cal*camp_cal_U2$variables$WEBORD)
sum(camp_cal_U2$variables$WEBORD)
sum(camp_cal_U2$variables$wgt.cal)
nrow(ict[ict$mode=="obs",])
sum(ict$WEBORD[ict$mode=="obs"])
#------------------------------------------------------------------------------------
# Estimates of web-ordering

WEBORDTotal <- sum(obs_and_pred$pred_prob) + 
                sum(pred$pred_prob) +
              svystatTM(camp_cal_U1, y= ~ diff,  estimator= "Total", 
                            conf.int= FALSE, conf.lev= 0.95, deff= FALSE, na.rm= FALSE)$Total +
              svystatTM(camp_cal_U2, y= ~ WEBORD ,  estimator= "Total", 
                            conf.int= FALSE, conf.lev= 0.95, deff= FALSE, na.rm= FALSE)$Total 
              
Zapsmall(WEBORDTotal)

WEBORDMean <- (sum(obs_and_pred$pred_prob) + 
              sum(pred$pred_prob) +
            svystatTM(camp_cal_U1, y= ~ diff,  estimator= "Total", 
                          conf.int= FALSE, conf.lev= 0.95, deff= FALSE, na.rm= FALSE)$Total +
            svystatTM(camp_cal_U2, y= ~ WEBORD ,  estimator= "Total", 
                          conf.int= FALSE, conf.lev= 0.95, deff= FALSE, na.rm= FALSE)$Total ) / nrow(asia)
Zapsmall(WEBORDMean)

WEBORD_ATECO2 <- tapply(obs_and_pred$pred_prob,obs_and_pred$ATECO2,sum) +
  tapply(pred$pred_prob,pred$ATECO2,sum) +
  svystatTM(camp_cal_U1, y= ~ diff,  estimator= "Total", 
            by =~ATECO2 - 1,
            conf.int= FALSE, conf.lev= 0.95, deff= FALSE, na.rm= FALSE)$Total +
  svystatTM(camp_cal_U2, y= ~ WEBORD ,  estimator= "Total", 
            by =~ATECO2 - 1,
            conf.int= FALSE, conf.lev= 0.95, deff= FALSE, na.rm= FALSE)$Total 

Zapsmall(WEBORD_ATECO2)

WEBORD_naceist <- tapply(obs_and_pred$pred_prob,obs_and_pred$naceist,sum) +
                  tapply(pred$pred_prob,pred$naceist,sum) +
                  svystatTM(camp_cal_U1, y= ~ diff,  estimator= "Total", 
                        by =~naceist - 1,
                        conf.int= FALSE, conf.lev= 0.95, deff= FALSE, na.rm= FALSE)$Total +
                  svystatTM(camp_cal_U2, y= ~ WEBORD ,  estimator= "Total", 
                        by =~naceist - 1,
                        conf.int= FALSE, conf.lev= 0.95, deff= FALSE, na.rm= FALSE)$Total 

Zapsmall(WEBORD_naceist)

WEBORD_naceICT <- tapply(obs_and_pred$pred_prob,obs_and_pred$naceICT,sum) +
                  tapply(pred$pred_prob,pred$naceICT,sum) +
                  svystatTM(camp_cal_U1, y= ~ diff,  estimator= "Total", 
                      by =~naceICT - 1,
                      conf.int= FALSE, conf.lev= 0.95, deff= FALSE, na.rm= FALSE)$Total +
                  svystatTM(camp_cal_U2, y= ~ WEBORD ,  estimator= "Total", 
                      by =~naceICT - 1,
                      conf.int= FALSE, conf.lev= 0.95, deff= FALSE, na.rm= FALSE)$Total 

Zapsmall(WEBORD_naceICT)

WEBORD_clad4 <- tapply(obs_and_pred$pred_prob,obs_and_pred$clad4,sum) +
                tapply(pred$pred_prob,pred$clad4,sum) +
                svystatTM(camp_cal_U1, y= ~ diff,  estimator= "Total", 
                    by =~clad4 - 1,
                    conf.int= FALSE, conf.lev= 0.95, deff= FALSE, na.rm= FALSE)$Total +
                svystatTM(camp_cal_U2, y= ~ WEBORD ,  estimator= "Total", 
                    by =~clad4 - 1,
                    conf.int= FALSE, conf.lev= 0.95, deff= FALSE, na.rm= FALSE)$Total 
Zapsmall(WEBORD_clad4)


WEBORD_dom3 <-  tapply(obs_and_pred$pred_prob,obs_and_pred$dom3,sum) +
                tapply(pred$pred_prob,pred$dom3,sum) +
                svystatTM(camp_cal_U1, y= ~ diff,  estimator= "Total", 
                    by =~dom3 - 1,
                    conf.int= FALSE, conf.lev= 0.95, deff= FALSE, na.rm= FALSE)$Total +
                svystatTM(camp_cal_U2, y= ~ WEBORD ,  estimator= "Total", 
                    by =~dom3 - 1,
                    conf.int= FALSE, conf.lev= 0.95, deff= FALSE, na.rm= FALSE)$Total 

Zapsmall(WEBORD_dom3)

WEBORD_reg21 <- tapply(obs_and_pred$pred_prob,obs_and_pred$reg21,sum) +
                tapply(pred$pred_prob,pred$reg21,sum) +
                svystatTM(camp_cal_U1, y= ~ diff,  estimator= "Total", 
                      by =~reg21 - 1,
                      conf.int= FALSE, conf.lev= 0.95, deff= FALSE, na.rm= FALSE)$Total +
                svystatTM(camp_cal_U2, y= ~ WEBORD ,  estimator= "Total", 
                      by =~reg21 - 1,
                      conf.int= FALSE, conf.lev= 0.95, deff= FALSE, na.rm= FALSE)$Total 

Zapsmall(WEBORD_reg21)


out <- NULL
out$dom <- c("Total",rep("naceist",27),
             rep("naceICT",2),
             rep("clad4",4),
             rep("dom3",16),
             rep("reg21",21),
             rep("ATECO2",62))
out$estimate <- c("Total",
                  levels(ict$naceist),
                  levels(ict$naceICT),
                  levels(ict$clad4),
                  levels(ict$dom3),
                  levels(ict$reg21),
                  levels(ict$ATECO2))
out$sample <- c(nrow(survey),
                as.numeric(table(survey$naceist)),
                as.numeric(table(survey$naceICT)),
                as.numeric(table(survey$clad4)),
                as.numeric(table(survey$dom3)),
                as.numeric(table(survey$reg21)),
                as.numeric(table(survey$ATECO2)))
out$population <- c(nrow(asia),
                    as.numeric(table(asia$naceist)),
                    as.numeric(table(asia$naceICT)),
                    as.numeric(table(asia$clad4)),
                    as.numeric(table(asia$dom3)),
                    as.numeric(table(asia$reg21)),
                    as.numeric(table(asia$ATECO2)))
# out$websites <- c(round(website_tot),
#                   round(website_naceist),
#                   round(website_naceICT),
#                   round(website_clad4),
#                   round(website_dom3),
#                   round(website_reg21))
out$WEBORD <- c(round(WEBORDTotal),
                     round(WEBORD_naceist),
                     round(WEBORD_naceICT),
                     round(WEBORD_clad4),
                     round(WEBORD_dom3),
                     round(WEBORD_reg21),
                     round(WEBORD_ATECO2))
out <- as.data.frame((out))
#out$websites_100 <- round(out$websites * 100 / out$population,2)
out$WEBORD_100 <- round(out$WEBORD * 100 / out$population,2)

write.table(out,"ICT_estimates_combined_assisted.csv",sep=";",row.names=F,col.names=TRUE,quote=FALSE)

