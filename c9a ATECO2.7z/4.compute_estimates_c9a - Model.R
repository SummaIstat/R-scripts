#------------------------------------------------------------------------------------
# ICT estimation of web ordering
# MODEL BASED METHOD WITH PSEUDO-CALIBRATION
# y = calibrated_estimate(observed+predicted)
#------------------------------------------------------------------------------------
library(ReGenesees)
# Read population
#library(data.table)
asia <- read.csv("pop.csv")
asia$naceICT <- as.factor(asia$naceICT)
asia$naceist <- as.factor(asia$naceist)
asia$mac4 <- as.factor(asia$mac4)
asia$clad4 <- as.factor(asia$clad4)
asia$reg21 <- as.factor(asia$reg21)
asia$TN <- as.factor(asia$TN)
asia$ATECO2 <- as.factor(asia$ATECO2)

table(asia$naceICT)
table(asia$naceist)
table(asia$mac4)
table(asia$clad4)
table(asia$reg21)
table(asia$ATECO2)
#------------------------------------------------------------------------------------
# Read survey data
survey <- read.delim("surveyICT2017.txt")

# colnames(survey)[1] <- "codice_unita"
# survey <- merge(survey,asia,by=c("codice"))
# 
# survey$naceICT <- as.factor(survey$naceICT)
# survey$naceist <- as.factor(survey$naceist)
# survey$mac4 <- as.factor(survey$mac4)
# survey$clad4 <- as.factor(survey$clad4)
# survey$reg21 <- as.factor(survey$reg21)
# survey$TN <- as.factor(survey$TN)
# 
# survey$cens <- ifelse(
#   (survey$clad4 >= "cl4" | survey$naceist == "ist21" | 
#      (survey$naceist == "ist14" & survey$clad4 == "cl3")
#    | survey$naceist == "ist28"), 1, 0 )
# 
# survey$stratum <- as.factor(paste("cens","naceist","naceICT","mac4","clad4","reg21",sep=""))
 survey$WEB <- ifelse(is.na(survey$WEB),0,survey$WEB)
 table(survey$WEB,useNA="ifany")
# survey$WEB <- ifelse(is.na(survey$WEB),0,survey$WEB)
# table(survey$WEB,useNA="ifany")
# 
# survey$WEBORD <- ifelse(is.na(survey$WEBORD),0,survey$WEBORD)
# table(survey$WEBORD,useNA="ifany")
#------------------------------------------------------------------------------------
# Estimates of population with websites

website_tot <- sum(survey$WEB * survey$coef.cal)

website_ATECO2 <- tapply(survey$WEB * survey$coef.cal,survey$ATECO2,sum)/tapply(survey$coef.cal,survey$ATECO2,sum)
website_ATECO2
 
website_naceist <- tapply(survey$WEB * survey$coef.cal,survey$naceist,sum)/tapply(survey$coef.cal,survey$naceist,sum)
website_naceist

website_naceICT <- tapply(survey$WEB * survey$coef.cal,survey$naceICT,sum)/tapply(survey$coef.cal,survey$naceICT,sum)
website_naceICT

website_clad4 <- tapply(survey$WEB * survey$coef.cal,survey$clad4,sum)/tapply(survey$coef.cal,survey$clad4,sum)
website_clad4

website_reg21 <- tapply(survey$WEB * survey$coef.cal,survey$reg21,sum)/tapply(survey$coef.cal,survey$reg21,sum)
website_reg21

website_dom3 <- tapply(survey$WEB * survey$coef.cal,survey$dom3,sum)/tapply(survey$coef.cal,survey$dom3,sum)
website_dom3

websites <- c(website_ATECO2,
              # website_naceist[2:27],
              website_naceICT[2],
              website_clad4[2:4],
              website_dom3[2:16],
              website_reg21[2:21])

#------------------------------------------------------------------------------------
# Read ICT data (obs+pred)
ict <- read.table("ict2017_c9a.txt",sep="\t",header=TRUE)
ict$wgt <- nrow(asia)/nrow(ict)
ict$ATECO2 <- as.factor(ict$ATECO2)
ict$stratum <- as.factor(paste(ict$naceist,ict$naceICT,ict$clad4,ict$reg21,sep=""))
table(ict$mode,ict$WEBORD)
rowSums(table(ict$mode,ict$WEBORD))
table(ict$mode,ict$WEBORD)/rowSums(table(ict$mode,ict$WEBORD))

table(survey$WEBORD[survey$WEB==1])/nrow(survey[survey$WEB==1,])
survey$WEBORD <- ifelse(is.na(survey$WEBORD),0,survey$WEBORD)
sum(survey$WEBORD*survey$coef.cal)/sum(survey$coef.cal)
mean(survey$WEBORD)*nrow(asia)
table(ict$WEBORD[ict$mode=="obs"|ict$mode=="obs_and_pred"])/nrow(ict[ict$mode=="obs"|ict$mode=="obs_and_pred",])
mean(survey$coef)
mean(survey$coef[survey$WEBORD==0])
mean(survey$coef[survey$WEBORD==1])
mean(survey$coef.cal)
mean(survey$coef.cal[survey$WEBORD==0])
mean(survey$coef.cal[survey$WEBORD==1])

#------------------------------------------
# Attribution of predicted scores to WEBORD
tapply(ict$WEBORD,ict$mode,sum)
pred <- read.delim("test_probs.txt")
pred <- pred[order(pred$codice_unita),]
ict <- ict[order(ict$codice_unita),]
ict$WEBORD[ict$mode=="pred"] <- pred$pred_prob
tapply(ict$WEBORD,ict$mode,sum)

pred <- read.delim("train_probs.txt")
pred <- pred[order(pred$codice_unita),]
pred <- pred[pred$codice_unita %in% ict$codice_unita[ict$mode == "obs_and_pred"],]
ict <- ict[order(ict$codice_unita),]
ict$WEBORD[ict$mode=="obs_and_pred"] <- pred$pred_prob
tapply(ict$WEBORD,ict$mode,sum)

#------------------------------------------
surv <- survey[survey$codice_unita %in% ict$codice_unita[ict$mode=="obs_and_pred"] & survey$WEB == 1,]
table(surv$WEBORD)/nrow(surv)
sum(surv$WEBORD*surv$coef.cal)/sum(surv$coef.cal)
mean(surv$coef)
mean(surv$coef[surv$WEBORD==0])
mean(surv$coef[surv$WEBORD==1])
mean(surv$coef.cal)
mean(surv$coef.cal[surv$WEBORD==0])
mean(surv$coef.cal[surv$WEBORD==1])

surv <- survey[survey$codice_unita %in% ict$codice_unita[ict$mode=="obs"] & survey$WEB == 1,]
table(surv$WEBORD)/nrow(surv)
sum(surv$WEBORD*surv$coef.cal)/sum(surv$coef.cal)
mean(surv$coef)
mean(surv$coef[surv$WEBORD==0])
mean(surv$coef[surv$WEBORD==1])
mean(surv$coef.cal)
mean(surv$coef.cal[surv$WEBORD==0])
mean(surv$coef.cal[surv$WEBORD==1])


camp <- e.svydesign(data= ict, ids= ~ codice_unita, strata= ~ stratum, 
                    weights= ~ wgt, fpc= NULL, self.rep.str= NULL, check.data= TRUE)


options(RG.lonely.psu = "average")
tot_cov = pop.template(data = ict, 
                       calmodel = ~ATECO2 + naceICT + clad4 + dom3 + reg21 - 1) 
tot_cov = fill.template(universe = asia, template = tot_cov)
sum(tot_cov[1:62])
sum(tot_cov[63])
tot_cov_web = tot_cov
tot_cov_web[,] =  tot_cov * websites
sum(tot_cov_web[1:62])

bounds.hint(camp, tot_cov_web)
#pop.desc(tot_cov)
camp_cal = e.calibrate(design = camp, df.population = tot_cov_web,
                       calmodel = ~ATECO2 + naceICT + clad4 + dom3 + reg21 - 1,
                       calfun = "linear", bounds = c(-1E6, 1E6), aggregate.stage = NULL, 
                       # sigma2 = ~ADDETTI,
                       maxit = 50, epsilon = 1e-07, force = TRUE)


summary(weights(camp_cal))
g.range(camp_cal)
check.cal(camp_cal)

#------------------------------------------------------------------------------------
# Estimates of job vacancies

WEBORDTotal <- svystatTM(camp_cal, y= ~ WEBORD ,  estimator= "Total", 
                            conf.int= FALSE, conf.lev= 0.95, deff= FALSE, na.rm= FALSE)
Zapsmall(WEBORDTotal)

WEBORDMean <- svystatTM(camp_cal, y= ~ WEBORD ,  estimator= "Mean", 
                    conf.int= FALSE, conf.lev= 0.95, deff= FALSE, na.rm= FALSE)
Zapsmall(WEBORDMean)

WEBORD_ATECO2 <- svystatTM(camp_cal, y= ~ WEBORD ,  estimator= "Total", 
                            by =~ATECO2 - 1,
                            conf.int= FALSE, conf.lev= 0.95, deff= FALSE, na.rm= FALSE)
Zapsmall(WEBORD_ATECO2)

WEBORD_naceist <- svystatTM(camp_cal, y= ~ WEBORD ,  estimator= "Total", 
                             by =~naceist - 1,
                             conf.int= FALSE, conf.lev= 0.95, deff= FALSE, na.rm= FALSE)
Zapsmall(WEBORD_naceist)


WEBORD_naceICT <- svystatTM(camp_cal, y= ~ WEBORD ,  estimator= "Total", 
                            by =~naceICT - 1,
                            conf.int= FALSE, conf.lev= 0.95, deff= FALSE, na.rm= FALSE)
Zapsmall(WEBORD_naceICT)


WEBORD_clad4 <- svystatTM(camp_cal, y= ~ WEBORD ,  estimator= "Total", 
                            by =~clad4 - 1,
                            conf.int= FALSE, conf.lev= 0.95, deff= FALSE, na.rm= FALSE)
Zapsmall(WEBORD_clad4)


WEBORD_dom3 <- svystatTM(camp_cal, y= ~ WEBORD ,  estimator= "Total", 
                          by =~dom3 - 1,
                          conf.int= FALSE, conf.lev= 0.95, deff= FALSE, na.rm= FALSE)
Zapsmall(WEBORD_dom3)


WEBORD_reg21 <- svystatTM(camp_cal, y= ~ WEBORD ,  estimator= "Total", 
                         by =~reg21 - 1,
                         conf.int= FALSE, conf.lev= 0.95, deff= FALSE, na.rm= FALSE)
Zapsmall(WEBORD_reg21)

out <- NULL
out$dom <- c("Total",rep("naceist",27),
             rep("naceICT",2),
             rep("clad4",4),
             rep("dom3",16),
             rep("reg21",21),
             rep("ATECO",62))
out$estimate <- c("Total",
                  levels(ict$naceist),
                  levels(ict$naceICT),
                  levels(ict$clad4),
                  levels(ict$dom3),
                  levels(ict$reg21),
                  levels(ict$ATECO2))
out$sample <- c(nrow(survey),
                as.numeric(table(survey$naceist)),
                as.numeric(table(survey$naceICT)),
                as.numeric(table(survey$clad4)),
                as.numeric(table(survey$dom3)),
                as.numeric(table(survey$reg21)),
                as.numeric(table(survey$ATECO2)))
out$population <- c(nrow(asia),
                    as.numeric(table(asia$naceist)),
                    as.numeric(table(asia$naceICT)),
                    as.numeric(table(asia$clad4)),
                    as.numeric(table(asia$dom3)),
                    as.numeric(table(asia$reg21)),
                    as.numeric(table(asia$ATECO2)))
# out$websites <- c(round(website_tot),
#                   round(website_naceist),
#                   round(website_naceICT),
#                   round(website_clad4),
#                   round(website_dom3),
#                   round(website_reg21))
out$WEBORD <- c(round(WEBORDTotal$Total),
                     round(WEBORD_naceist$Total.WEBORD),
                     round(WEBORD_naceICT$Total.WEBORD),
                     round(WEBORD_clad4$Total.WEBORD),
                     round(WEBORD_dom3$Total.WEBORD),
                     round(WEBORD_reg21$Total.WEBORD),
                     round(WEBORD_ATECO2$Total.WEBORD))
out <- as.data.frame((out))
#out$websites_100 <- round(out$websites * 100 / out$population,2)
out$WEBORD_100 <- round(out$WEBORD * 100 / out$population,2)


write.table(out,"ICT_estimates_model_based.csv",sep=";",row.names=F,col.names=TRUE,quote=FALSE)
