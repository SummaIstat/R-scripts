
est0 <- read.csv2("ICT_estimates_design.csv",dec=".")
colnames(est0)[1] <- c("type")
colnames(est0)[2] <- c("dom")
colnames(est0)[6] <- c("design")
colnames(est0)[7] <- c("design_lower")
colnames(est0)[8] <- c("design_upper")

est1 <- read.csv2("ICT_estimates_Model_based.csv",dec=".")
est1 <- est1[,c("dom","estimate","WEBVAC_100")]
colnames(est1) <- c("type","dom","model_based")

est2 <- read.csv2("ICT_estimates_combined_assisted.csv",dec=".")
est2 <- est2[,c("dom","estimate","WEBVAC_100")]
colnames(est2) <- c("type","dom","combined")


estims <- merge(est0,est1,by=c("dom")) 
estims <- merge(estims,est2,by=c("dom")) 
estims <- estims[order(estims$websites),]



pdf(file="Job advertisements combined vs design based vs model based.pdf")

# ---------------- cl44 ------------------------------------
est <- estims[estims$type.x == "clad4" | estims$type.x == "Total",]
num <- length(droplevels(est$dom))
maxi = (max(c(est$combined),(est$design_upper),(est$model_based)))
plot(est$design_upper, col = "darkgreen", lty = 4, type = "l", pch = "�", cex = 3,cex.lab = 1.3,
     xlab = "", 
     ylab = "Job advertisements % ",
     ylim = c(0,maxi), axes = F)
points(est$design, col = "darkgreen", lty = 4, type = "p", pch = "�", cex = 2)
points(est$design_lower, col = "darkgreen", lty = 4, type = "l", pch = "�", cex = 2)
points(est$model_based, col = "darkred", lty = 4, type = "p", pch = "+", cex = 2)
points(est$combined, col = "blue", lty = 4, type = "p", pch = "*", cex = 2)

abline(0,0)
axis(1, at=1:num, labels = est$dom,las=2)
axis(2, at=seq(0,maxi+10,5), labels=seq(0,maxi+10,5))
legend("topright",
       legend = c("Design based","Model based","Combined"), 
       pch = c("�","+","*"),
       col = c("darkgreen","darkred","blue"),
       ncol = 1, cex = 0.9, text.font = 1.5)
title("Job advertisements by 4 classes of employees",cex.main=1)



# ---------------- mac4 * cl4 ------------------------------------
est <- estims[estims$type.x == "dom3" | estims$type.x == "Total",]
num <- length(droplevels(est$dom))
maxi = (max(c(est$combined),(est$design_upper),(est$model_based)))
plot(est$design_upper, col = "darkgreen", lty = 4, type = "l", pch = "�", cex = 3,cex.lab = 1.3,
     xlab = "", 
     ylab = "Job advertisements % ",
     ylim = c(0,maxi), axes = F)
points(est$design, col = "darkgreen", lty = 4, type = "p", pch = "�", cex = 2)
points(est$design_lower, col = "darkgreen", lty = 4, type = "l", pch = "�", cex = 2)
points(est$model_based, col = "darkred", lty = 4, type = "p", pch = "+", cex = 2)
points(est$combined, col = "blue", lty = 4, type = "p", pch = "*", cex = 2)

abline(0,0)
axis(1, at=1:num, labels = est$dom,las=2)
axis(2, at=seq(0,maxi+10,5), labels=seq(0,maxi+10,5))
legend("topright",
       legend = c("Design based","Model based","Combined"), 
       pch = c("�","+","*"),
       col = c("darkgreen","darkred","blue"),
       ncol = 1, cex = 0.9, text.font = 1.5)
title("Job advertisements by 4 groups NACE and 4 classes of employees",cex.main=1)

# ---------------- naceist ------------------------------------
est <- estims[estims$type.x == "naceist" | estims$type.x == "Total",]
num <- length(droplevels(est$dom))
maxi = (max(c(est$combined),(est$design_upper),(est$model_based)))
plot(est$design_upper, col = "darkgreen", lty = 4, type = "l", pch = "�", cex = 3,cex.lab = 1.3,
     xlab = "", 
     ylab = "Job advertisements % ",
     ylim = c(0,maxi), axes = F)
points(est$design, col = "darkgreen", lty = 4, type = "p", pch = "�", cex = 2)
points(est$design_lower, col = "darkgreen", lty = 4, type = "l", pch = "�", cex = 2)
points(est$model_based, col = "darkred", lty = 4, type = "p", pch = "+", cex = 2)
points(est$combined, col = "blue", lty = 4, type = "p", pch = "*", cex = 2)

abline(0,0)
axis(1, at=1:num, labels = est$dom,las=2)
axis(2, at=seq(0,maxi+10,5), labels=seq(0,maxi+10,5))
legend("topright",
       legend = c("Design based","Model based","Combined"), 
       pch = c("�","+","*"),
       col = c("darkgreen","darkred","blue"),
       ncol = 1, cex = 0.9, text.font = 1.5)
title("Job advertisements by 27 groups NACE",cex.main=1)

# ---------------- regions ------------------------------------
est <- estims[estims$type.x == "reg21" | estims$type.x == "Total",]
num <- length(droplevels(est$dom))
maxi = (max(c(est$combined),(est$design_upper),(est$model_based)))
plot(est$design_upper, col = "darkgreen", lty = 4, type = "l", pch = "�", cex = 3,cex.lab = 1.3,
     xlab = "", 
     ylab = "Job advertisements % ",
     ylim = c(0,maxi), axes = F)
points(est$design, col = "darkgreen", lty = 4, type = "p", pch = "�", cex = 2)
points(est$design_lower, col = "darkgreen", lty = 4, type = "l", pch = "�", cex = 2)
points(est$model_based, col = "darkred", lty = 4, type = "p", pch = "+", cex = 2)
points(est$combined, col = "blue", lty = 4, type = "p", pch = "*", cex = 2)

abline(0,0)
axis(1, at=1:num, labels = est$dom,las=2)
axis(2, at=seq(0,maxi+10,5), labels=seq(0,maxi+10,5))
legend("topright",
       legend = c("Design based","Model based","Combined"), 
       pch = c("�","+","*"),
       col = c("darkgreen","darkred","blue"),
       ncol = 1, cex = 0.9, text.font = 1.5)
title("Job advertisements by regions",cex.main=1)

# ---------------- ICTs ------------------------------------
est <- estims[estims$type.x == "naceICT" | estims$type.x == "Total",]
num <- length(droplevels(est$dom))
maxi = (max(c(est$combined),(est$design_upper),(est$model_based)))
plot(est$design_upper, col = "darkgreen", lty = 4, type = "l", pch = "�", cex = 3,cex.lab = 1.3,
     xlab = "", 
     ylab = "Job advertisements % ",
     ylim = c(0,maxi), axes = F)
points(est$design, col = "darkgreen", lty = 4, type = "p", pch = "�", cex = 2)
points(est$design_lower, col = "darkgreen", lty = 4, type = "l", pch = "�", cex = 2)
points(est$model_based, col = "darkred", lty = 4, type = "p", pch = "+", cex = 2)
points(est$combined, col = "blue", lty = 4, type = "p", pch = "*", cex = 2)

abline(0,0)
axis(1, at=1:num, labels = est$dom,las=2)
axis(2, at=seq(0,maxi+10,5), labels=seq(0,maxi+10,5))
legend("bottomleft",
       legend = c("Design based","Model based","Combined"), 
       pch = c("�","+","*"),
       col = c("darkgreen","darkred","blue"),
       ncol = 1, cex = 0.9, text.font = 1.5)
title("Job advertisements by ICT (no/yes)",cex.main=1)

# ---------------- ATECO2 ------------------------------------
est <- estims[estims$type.x == "ATECO2" | estims$type.x == "Total",]
est <- est[order(est$type,est$dom),]
num <- length(droplevels(est$dom))
# maxi = (max(c(est$combined),(est$design_upper),(est$model_based)))
maxi = (max(c(est$design_upper,est$model_based)))

plot(est$design_upper, col = "darkgreen", lty = 4, type = "l", pch = "�", cex = 3,cex.lab = 1.3,
     xlab = "", 
     ylab = "Job advertisements % ",
     # ylim = c(0,100), axes = F)
     ylim = c(0,maxi), axes = F)
points(est$design, col = "darkgreen", lty = 4, type = "p", pch = "�", cex = 2)
points(est$design_lower, col = "darkgreen", lty = 4, type = "l", pch = "�", cex = 2)
points(est$model_based, col = "darkred", lty = 4, type = "p", pch = "+", cex = 2)
# points(est$combined, col = "blue", lty = 4, type = "p", pch = "*", cex = 2)

abline(0,0)
axis(1, at=1:num, labels = est$dom,las=2)
axis(2, at=seq(0,maxi+10,5), labels=seq(0,maxi+10,5))
legend("topright",
       legend = c("Design based","Model based"), 
       pch = c("�","+"),
       col = c("darkgreen","darkred"),
       ncol = 1, cex = 0.9, text.font = 1.5)
title("Job advertisements by ATECO2 (no/yes)",cex.main=1)


dev.off()
#  est <- NULL
#  est$type_dom <- estims$type
#  est$dom <- estims$dom
#  est$design <- estims$design
#  est$model_based <- estims$model_based
#  est$combined <- estims$combined
#  est <- as.data.frame(est)
est <- estims[,c("dom","type","sample","population","websites","design","design_lower","design_upper","model_based","combined")]
est <- est[order(est$type,est$dom),]
write.table(est,"Job_advertisements_estimates_compared.csv",sep=";",row.names=F,
            col.names=T,quote=F)

